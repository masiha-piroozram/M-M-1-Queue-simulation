library(queueing)
summary(QueueingModel(NewInput.MM1(lambda = 1/5 , mu = 1/3 )))
